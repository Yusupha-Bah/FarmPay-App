// Global variables
let currentUser = {
    name: 'Yusupha Bah',
    email: 'bahyy5098@gmail.com',
    phone: '+220 3070487',
    balance: 85000.00
};

let transactions = [
    {
        id: 1,
        type: 'sent',
        recipient: 'Usuf Bah',
        amount: 150.00,
        date: '2024-01-15',
        time: '14:30',
        status: 'success',
        note: 'Lunch payment'
    },
    {
        id: 2,
        type: 'received',
        sender: 'Jainaba Bah',
        amount: 300.00,
        date: '2024-01-14',
        time: '09:15',
        status: 'success',
        note: 'Payment for services'
    },
    {
        id: 3,
        type: 'bills',
        service: 'Electricity',
        amount: 75.00,
        date: '2024-01-13',
        time: '16:45',
        status: 'success',
        note: 'Monthly bill'
    },
    {
        id: 4,
        type: 'sent',
        recipient: 'Mami Darboe',
        amount: 50.00,
        date: '2024-01-12',
        time: '11:20',
        status: 'pending',
        note: 'Coffee money'
    },
    {
        id: 5,
        type: 'received',
        sender: 'Lamin Barrow',
        amount: 200.00,
        date: '2024-01-11',
        time: '13:10',
        status: 'success',
        note: 'Project payment'
    }
];

// LocalStorage Helper Functions
const storage = {
    get: (key) => {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : null;
        } catch (error) {
            console.error('Storage get error:', error);
            return null;
        }
    },
    set: (key, value) => {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (error) {
            console.error('Storage set error:', error);
            return false;
        }
    },
    remove: (key) => {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (error) {
            console.error('Storage remove error:', error);
            return false;
        }
    }
};

// Initialize data from localStorage or use defaults
const initializeData = () => {
    const savedUser = storage.get('farmpay_user');
    const savedTransactions = storage.get('farmpay_transactions');
    
    if (savedUser) {
        currentUser = { ...currentUser, ...savedUser };
    }
    
    if (savedTransactions) {
        transactions = savedTransactions;
    } else {
        // Save default transactions to localStorage
        storage.set('farmpay_transactions', transactions);
    }
};

let currentFilter = 'all';

// Page Navigation
function showPage(pageId) {
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => {
        page.classList.remove('active');
    });
    
    // Show target page
    const targetPage = document.getElementById(pageId);
    if (targetPage) {
        targetPage.classList.add('active');
        
        // Load page-specific content
        if (pageId === 'dashboard-page') {
            loadDashboard();
        } else if (pageId === 'history-page') {
            loadTransactionHistory();
        }
    }
}

// Set active navigation item
function setActiveNav(navItem) {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => item.classList.remove('active'));
    navItem.classList.add('active');
}

// Password toggle functionality
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const button = input.nextElementSibling;
    const icon = button.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Form validation and submission
document.addEventListener('DOMContentLoaded', function() {
    // Login form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleLogin();
        });
    }
    
    // Signup form
    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleSignup();
        });
    }
    
    // Forgot password form
    const forgotPasswordForm = document.getElementById('forgot-password-form');
    if (forgotPasswordForm) {
        forgotPasswordForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleForgotPassword();
        });
    }
    
    // Initialize dashboard
    loadDashboard();
});

// Handle login
function handleLogin() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    if (!email || !password) {
        showNotification('Please fill in all fields', 'error');
        return;
    }
    
    // Simulate login process
    showNotification('Logging in...', 'info');
    
    setTimeout(() => {
        // For demo purposes, accept any login
        // In real app, validate credentials
        showPage('dashboard-page');
        showNotification('Welcome back!', 'success');
    }, 1500);
}

// Handle signup
function handleSignup() {
    const name = document.getElementById('signup-name').value;
    const email = document.getElementById('signup-email').value;
    const phone = document.getElementById('signup-phone').value;
    const password = document.getElementById('signup-password').value;
    const confirmPassword = document.getElementById('signup-confirm-password').value;
    const agreeTerms = document.getElementById('agree-terms').checked;
    
    // Validation
    if (!name || !email || !phone || !password || !confirmPassword) {
        showNotification('Please fill in all fields', 'error');
        return;
    }
    
    if (password !== confirmPassword) {
        showNotification('Passwords do not match', 'error');
        return;
    }
    
    if (!agreeTerms) {
        showNotification('Please agree to the terms and conditions', 'error');
        return;
    }
    
    // Simulate signup process
    showNotification('Creating account...', 'info');
    
    setTimeout(() => {
        // Update user data
        currentUser = {
            name: name,
            email: email,
            phone: phone,
            balance: 0.00
        };
        
        // Save to localStorage
        storage.set('farmpay_user', currentUser);
        
        showPage('dashboard-page');
        showNotification('Account created successfully!', 'success');
    }, 1500);
}

// Handle forgot password
function handleForgotPassword() {
    const email = document.getElementById('reset-email').value;
    
    if (!email) {
        showNotification('Please enter your email address', 'error');
        return;
    }
    
    showNotification('Reset link sent to your email', 'success');
    setTimeout(() => {
        showPage('login-page');
    }, 2000);
}

// Load dashboard
function loadDashboard() {
    // Update user info
    const userDetails = document.querySelector('.user-details h3');
    if (userDetails) {
        userDetails.textContent = `Welcome back, ${currentUser.name.split(' ')[0]}!`;
    }
    
    // Update balance
    const balanceAmount = document.querySelector('.balance-amount');
    if (balanceAmount) {
        balanceAmount.textContent = `GMD ${currentUser.balance.toFixed(2)}`;
    }
    
    // Load recent transactions
    loadRecentTransactions();
}

// Load recent transactions
function loadRecentTransactions() {
    const container = document.getElementById('recent-transactions');
    if (!container) return;
    
    container.innerHTML = '';
    
    // Get last 3 transactions
    const recentTransactions = transactions.slice(0, 3);
    
    recentTransactions.forEach(transaction => {
        const transactionElement = createTransactionElement(transaction);
        container.appendChild(transactionElement);
    });
}

// Load transaction history
function loadTransactionHistory() {
    const container = document.getElementById('transaction-history');
    if (!container) return;
    
    container.innerHTML = '';
    
    let filteredTransactions = transactions;
    
    // Apply filter
    if (currentFilter !== 'all') {
        filteredTransactions = transactions.filter(t => t.type === currentFilter);
    }
    
    filteredTransactions.forEach(transaction => {
        const transactionElement = createTransactionElement(transaction);
        container.appendChild(transactionElement);
    });
}

// Create transaction element
function createTransactionElement(transaction) {
    const div = document.createElement('div');
    div.className = 'transaction-item';
    
    let icon, title, subtitle, amount, status;
    
    switch (transaction.type) {
        case 'sent':
            icon = '<i class="fas fa-arrow-up"></i>';
            title = `Sent to ${transaction.recipient}`;
            subtitle = `${transaction.date} at ${transaction.time}`;
            amount = `-GMD ${transaction.amount.toFixed(2)}`;
            break;
        case 'received':
            icon = '<i class="fas fa-arrow-down"></i>';
            title = `Received from ${transaction.sender}`;
            subtitle = `${transaction.date} at ${transaction.time}`;
            amount = `+GMD ${transaction.amount.toFixed(2)}`;
            break;
        case 'bills':
            icon = '<i class="fas fa-file-invoice"></i>';
            title = `Paid ${transaction.service}`;
            subtitle = `${transaction.date} at ${transaction.time}`;
            amount = `-GMD ${transaction.amount.toFixed(2)}`;
            break;
    }
    
    div.innerHTML = `
        <div class="transaction-icon ${transaction.type}">
            ${icon}
        </div>
        <div class="transaction-details">
            <h4>${title}</h4>
            <p>${subtitle}</p>
            ${transaction.note ? `<p style="font-size: 0.8rem; color: #999;">${transaction.note}</p>` : ''}
        </div>
        <div style="text-align: right;">
            <div class="transaction-amount ${transaction.type}">${amount}</div>
            <div class="transaction-status ${transaction.status}">${transaction.status}</div>
        </div>
    `;
    
    return div;
}

// Filter transactions
function filterTransactions(filter) {
    currentFilter = filter;
    
    // Update active filter tab
    const filterTabs = document.querySelectorAll('.filter-tab');
    filterTabs.forEach(tab => tab.classList.remove('active'));
    event.target.classList.add('active');
    
    loadTransactionHistory();
}

// Send money functions
function showSendConfirmation() {
    const recipient = document.getElementById('recipient').value;
    const amount = parseFloat(document.getElementById('send-amount').value);
    const note = document.getElementById('send-note').value;
    
    if (!recipient || !amount || amount <= 0) {
        showNotification('Please fill in all required fields', 'error');
        return;
    }
    
    // Update confirmation page
    document.getElementById('confirm-recipient').textContent = recipient.split(' - ')[0];
    document.getElementById('confirm-phone').textContent = recipient.split(' - ')[1] || '';
    document.getElementById('confirm-amount').textContent = amount.toFixed(2);
    document.getElementById('detail-amount').textContent = `GMD ${amount.toFixed(2)}`;
    document.getElementById('detail-total').textContent = `GMD ${(amount + 5).toFixed(2)}`;
    
    if (note) {
        document.getElementById('note-text').textContent = note;
        document.getElementById('confirm-note').style.display = 'block';
    } else {
        document.getElementById('confirm-note').style.display = 'none';
    }
    
    showPage('send-confirmation-page');
}

// Process send money
function processSendMoney() {
    const amount = parseFloat(document.getElementById('send-amount').value);
    const recipient = document.getElementById('recipient').value;
    const note = document.getElementById('send-note').value;
    
    // Check if user has sufficient balance
    if (amount + 5 > currentUser.balance) {
        showNotification('Insufficient balance', 'error');
        return;
    }
    
    // Simulate transaction processing
    showNotification('Processing transaction...', 'info');
    
    setTimeout(() => {
        // Update balance
        currentUser.balance -= (amount + 5);
        
        // Add transaction to history
        const newTransaction = {
            id: transactions.length + 1,
            type: 'sent',
            recipient: recipient.split(' - ')[0],
            amount: amount,
            date: new Date().toISOString().split('T')[0],
            time: new Date().toLocaleTimeString('en-US', { hour12: false }),
            status: 'success',
            note: note
        };
        
        transactions.unshift(newTransaction);
        
        // Save to localStorage
        storage.set('farmpay_transactions', transactions);
        storage.set('farmpay_user', currentUser);
        
        // Show success modal
        showSuccessModal('Money Sent Successfully!', `GMD ${amount.toFixed(2)} has been sent to ${recipient.split(' - ')[0]}`);
        
        // Reset form
        document.getElementById('recipient').value = '';
        document.getElementById('send-amount').value = '';
        document.getElementById('send-note').value = '';
        
        showPage('dashboard-page');
    }, 2000);
}

// Add cash functions
function setAmount(amount) {
    document.getElementById('add-amount').value = amount;
}

function showAddCashConfirmation() {
    const amount = parseFloat(document.getElementById('add-amount').value);
    const paymentMethod = document.getElementById('payment-method').value;
    
    if (!amount || amount <= 0 || !paymentMethod) {
        showNotification('Please fill in all required fields', 'error');
        return;
    }
    
    // Update confirmation page
    document.getElementById('topup-amount').textContent = amount.toFixed(2);
    document.getElementById('topup-detail-amount').textContent = `GMD ${amount.toFixed(2)}`;
    document.getElementById('topup-detail-total').textContent = `GMD ${amount.toFixed(2)}`;
    document.getElementById('payment-method-display').textContent = paymentMethod;
    
    showPage('add-cash-confirmation-page');
}

// Process add cash
function processAddCash() {
    const amount = parseFloat(document.getElementById('add-amount').value);
    const paymentMethod = document.getElementById('payment-method').value;
    
    // Simulate transaction processing
    showNotification('Processing top-up...', 'info');
    
    setTimeout(() => {
        // Update balance
        currentUser.balance += amount;
        
        // Add transaction to history
        const newTransaction = {
            id: transactions.length + 1,
            type: 'received',
            sender: 'Top-up',
            amount: amount,
            date: new Date().toISOString().split('T')[0],
            time: new Date().toLocaleTimeString('en-US', { hour12: false }),
            status: 'success',
            note: `Added via ${paymentMethod}`
        };
        
        transactions.unshift(newTransaction);
        
        // Save to localStorage
        storage.set('farmpay_transactions', transactions);
        storage.set('farmpay_user', currentUser);
        
        // Show success modal
        showSuccessModal('Top-up Successful!', `GMD ${amount.toFixed(2)} has been added to your wallet`);
        
        // Reset form
        document.getElementById('add-amount').value = '';
        document.getElementById('payment-method').value = '';
        
        showPage('dashboard-page');
    }, 2000);
}

// Bill payment functions
function selectBillCategory(category) {
    showNotification(`${category.charAt(0).toUpperCase() + category.slice(1)} bill payment coming soon!`, 'info');
}

// Profile functions
function editProfile() {
    showNotification('Edit profile feature coming soon!', 'info');
}

function showSettings() {
    showNotification('Settings page coming soon!', 'info');
}

function showSecurity() {
    showNotification('Security settings coming soon!', 'info');
}

function showHelp() {
    showNotification('Help & Support coming soon!', 'info');
}

function logout() {
    showNotification('Logging out...', 'info');
    setTimeout(() => {
        showPage('welcome-page');
        showNotification('Logged out successfully', 'success');
    }, 1000);
}

// Success modal functions
function showSuccessModal(title, message) {
    document.getElementById('success-title').textContent = title;
    document.getElementById('success-message').textContent = message;
    document.getElementById('success-modal').classList.add('active');
}

function closeSuccessModal() {
    document.getElementById('success-modal').classList.remove('active');
}

// Utility functions
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 12px;
        color: white;
        font-weight: 600;
        z-index: 3000;
        transform: translateX(100%);
        transition: transform 0.3s ease;
        max-width: 300px;
    `;
    
    // Set background color based on type
    switch (type) {
        case 'success':
            notification.style.background = 'linear-gradient(135deg, #4ade80 0%, #22c55e 100%)';
            break;
        case 'error':
            notification.style.background = 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)';
            break;
        case 'warning':
            notification.style.background = 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)';
            break;
        default:
            notification.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
    }
    
    notification.textContent = message;
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Recipient modal (placeholder)
function showRecipientModal() {
    showNotification('Contact picker coming soon!', 'info');
}

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    // Initialize data from localStorage
    initializeData();
    
    // Add some initial styling for better UX
    document.body.style.overflow = 'hidden';
    
    // Add smooth scrolling
    const style = document.createElement('style');
    style.textContent = `
        html {
            scroll-behavior: smooth;
        }
        
        .notification {
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }
    `;
    document.head.appendChild(style);
    
    // Add keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Escape key to go back
        if (e.key === 'Escape') {
            const activePage = document.querySelector('.page.active');
            if (activePage && activePage.id !== 'welcome-page') {
                const backBtn = activePage.querySelector('.back-btn');
                if (backBtn) {
                    backBtn.click();
                }
            }
        }
    });
    
    // Add touch gestures for mobile
    let touchStartX = 0;
    let touchStartY = 0;
    
    document.addEventListener('touchstart', function(e) {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
    });
    
    document.addEventListener('touchend', function(e) {
        if (!touchStartX || !touchStartY) return;
        
        const touchEndX = e.changedTouches[0].clientX;
        const touchEndY = e.changedTouches[0].clientY;
        
        const diffX = touchStartX - touchEndX;
        const diffY = touchStartY - touchEndY;
        
        // Swipe left to go back (if significant horizontal movement)
        if (Math.abs(diffX) > 50 && Math.abs(diffY) < 50) {
            const activePage = document.querySelector('.page.active');
            if (activePage && activePage.id !== 'welcome-page') {
                const backBtn = activePage.querySelector('.back-btn');
                if (backBtn) {
                    backBtn.click();
                }
            }
        }
        
        touchStartX = 0;
        touchStartY = 0;
    });
});

// Add some sample data for demonstration
function addSampleData() {
    // Add more sample transactions
    const sampleTransactions = [
        {
            id: 6,
            type: 'bills',
            service: 'Water',
            amount: 45.00,
            date: '2024-01-10',
            time: '10:30',
            status: 'success',
            note: 'Monthly water bill'
        },
        {
            id: 7,
            type: 'sent',
            recipient: 'Alex Turner',
            amount: 25.00,
            date: '2024-01-09',
            time: '15:20',
            status: 'success',
            note: 'Movie tickets'
        },
        {
            id: 8,
            type: 'received',
            sender: 'Emma Davis',
            amount: 180.00,
            date: '2024-01-08',
            time: '12:45',
            status: 'success',
            note: 'Rent payment'
        }
    ];
    
    transactions.push(...sampleTransactions);
}

// Initialize sample data
addSampleData();
