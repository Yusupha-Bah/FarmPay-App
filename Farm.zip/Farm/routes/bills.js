const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const moment = require('moment');
const router = express.Router();

// In-memory storage (replace with database in production)
let bills = [
    {
        id: '1',
        userId: '1',
        category: 'electricity',
        service: 'Gambia Electricity Company',
        accountNumber: 'EL123456789',
        amount: 75.00,
        dueDate: moment().add(5, 'days').toISOString(),
        status: 'unpaid',
        createdAt: moment().subtract(10, 'days').toISOString()
    },
    {
        id: '2',
        userId: '1',
        category: 'water',
        service: 'Gambia Water Company',
        accountNumber: 'WA987654321',
        amount: 45.00,
        dueDate: moment().add(3, 'days').toISOString(),
        status: 'unpaid',
        createdAt: moment().subtract(8, 'days').toISOString()
    }
];

let billPayments = [
    {
        id: '1',
        userId: '1',
        billId: '3',
        category: 'electricity',
        service: 'Gambia Electricity Company',
        amount: 75.00,
        fee: 2.00,
        total: 77.00,
        status: 'success',
        paidAt: moment().subtract(3, 'days').toISOString()
    }
];

// Middleware to validate JWT token
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ success: false, message: 'Access token required' });
    }

    req.user = { userId: '1' };
    next();
};

// Get bill categories
router.get('/categories', authenticateToken, (req, res) => {
    try {
        const categories = [
            {
                id: 'electricity',
                name: 'Electricity',
                icon: 'fas fa-bolt',
                description: 'Pay your electricity bills',
                providers: ['Gambia Electricity Company', 'Private Providers']
            },
            {
                id: 'water',
                name: 'Water',
                icon: 'fas fa-tint',
                description: 'Pay your water bills',
                providers: ['Gambia Water Company', 'Private Providers']
            },
            {
                id: 'internet',
                name: 'Internet',
                icon: 'fas fa-wifi',
                description: 'Pay your internet bills',
                providers: ['Gamtel', 'QCell', 'Comium', 'Africell']
            },
            {
                id: 'phone',
                name: 'Phone',
                icon: 'fas fa-phone',
                description: 'Pay your phone bills',
                providers: ['Gamcel', 'QCell', 'Comium', 'Africell']
            },
            {
                id: 'tv',
                name: 'TV',
                icon: 'fas fa-tv',
                description: 'Pay your TV subscription',
                providers: ['Gamtel TV', 'Private Providers']
            },
            {
                id: 'waste',
                name: 'Waste Management',
                icon: 'fas fa-trash',
                description: 'Pay waste collection fees',
                providers: ['Municipal Council', 'Private Collectors']
            }
        ];

        res.json({
            success: true,
            data: categories
        });

    } catch (error) {
        console.error('Get bill categories error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Get user's bills
router.get('/', authenticateToken, (req, res) => {
    try {
        const userId = req.user.userId;
        const { status, category } = req.query;

        let userBills = bills.filter(b => b.userId === userId);

        // Apply filters
        if (status) {
            userBills = userBills.filter(b => b.status === status);
        }

        if (category) {
            userBills = userBills.filter(b => b.category === category);
        }

        // Sort by due date (earliest first)
        userBills.sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate));

        res.json({
            success: true,
            data: userBills
        });

    } catch (error) {
        console.error('Get bills error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Get bill by ID
router.get('/:id', authenticateToken, (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.userId;

        const bill = bills.find(b => b.id === id && b.userId === userId);

        if (!bill) {
            return res.status(404).json({
                success: false,
                message: 'Bill not found'
            });
        }

        res.json({
            success: true,
            data: bill
        });

    } catch (error) {
        console.error('Get bill error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Pay bill
router.post('/:id/pay', [
    body('amount').isFloat({ min: 1 }).withMessage('Amount must be at least 1 GMD'),
    body('paymentMethod').isIn(['wallet', 'bank', 'mobile-money']).withMessage('Invalid payment method')
], authenticateToken, (req, res) => {
    try {
        // Check validation errors
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errors.array()
            });
        }

        const { id } = req.params;
        const { amount, paymentMethod } = req.body;
        const userId = req.user.userId;

        // Find bill
        const bill = bills.find(b => b.id === id && b.userId === userId);
        if (!bill) {
            return res.status(404).json({
                success: false,
                message: 'Bill not found'
            });
        }

        // Check if bill is already paid
        if (bill.status === 'paid') {
            return res.status(400).json({
                success: false,
                message: 'Bill is already paid'
            });
        }

        // Calculate fee (2 GMD for bill payments)
        const fee = 2.00;
        const total = parseFloat(amount) + fee;

        // Create bill payment record
        const billPayment = {
            id: uuidv4(),
            userId,
            billId: id,
            category: bill.category,
            service: bill.service,
            amount: parseFloat(amount),
            fee,
            total,
            paymentMethod,
            status: 'pending',
            createdAt: new Date().toISOString()
        };

        // Simulate payment processing
        setTimeout(() => {
            // Update payment status
            billPayment.status = 'success';
            billPayment.paidAt = new Date().toISOString();

            // Update bill status
            bill.status = 'paid';
            bill.paidAt = new Date().toISOString();

            // Add to bill payments
            billPayments.push(billPayment);

            console.log(`Bill payment successful: ${amount} GMD paid for ${bill.service}`);
        }, 2000);

        res.status(201).json({
            success: true,
            message: 'Bill payment initiated successfully',
            data: {
                paymentId: billPayment.id,
                amount: billPayment.amount,
                total: billPayment.total,
                status: billPayment.status
            }
        });

    } catch (error) {
        console.error('Pay bill error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Get bill payment history
router.get('/payments', authenticateToken, (req, res) => {
    try {
        const userId = req.user.userId;
        const userPayments = billPayments.filter(p => p.userId === userId);

        // Sort by creation date (newest first)
        userPayments.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        res.json({
            success: true,
            data: userPayments
        });

    } catch (error) {
        console.error('Get bill payments error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Get bill statistics
router.get('/stats', authenticateToken, (req, res) => {
    try {
        const userId = req.user.userId;
        const userBills = bills.filter(b => b.userId === userId);
        const userPayments = billPayments.filter(p => p.userId === userId);

        const stats = {
            totalBills: userBills.length,
            unpaidBills: userBills.filter(b => b.status === 'unpaid').length,
            paidBills: userBills.filter(b => b.status === 'paid').length,
            overdueBills: userBills.filter(b => 
                b.status === 'unpaid' && moment(b.dueDate).isBefore(moment())
            ).length,
            totalPaid: userPayments.reduce((sum, p) => sum + p.amount, 0),
            totalFees: userPayments.reduce((sum, p) => sum + p.fee, 0),
            thisMonth: userPayments.filter(p => 
                moment(p.createdAt).isSame(moment(), 'month')
            ).length
        };

        res.json({
            success: true,
            data: stats
        });

    } catch (error) {
        console.error('Get bill stats error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Add new bill (for testing)
router.post('/', [
    body('category').isIn(['electricity', 'water', 'internet', 'phone', 'tv', 'waste']).withMessage('Invalid category'),
    body('service').notEmpty().withMessage('Service name required'),
    body('accountNumber').notEmpty().withMessage('Account number required'),
    body('amount').isFloat({ min: 1 }).withMessage('Amount must be at least 1 GMD'),
    body('dueDate').isISO8601().withMessage('Valid due date required')
], authenticateToken, (req, res) => {
    try {
        // Check validation errors
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errors.array()
            });
        }

        const { category, service, accountNumber, amount, dueDate } = req.body;
        const userId = req.user.userId;

        const newBill = {
            id: uuidv4(),
            userId,
            category,
            service,
            accountNumber,
            amount: parseFloat(amount),
            dueDate,
            status: 'unpaid',
            createdAt: new Date().toISOString()
        };

        bills.push(newBill);

        res.status(201).json({
            success: true,
            message: 'Bill added successfully',
            data: newBill
        });

    } catch (error) {
        console.error('Add bill error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

module.exports = router; 