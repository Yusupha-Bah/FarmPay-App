const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const moment = require('moment');
const router = express.Router();

// In-memory storage (replace with database in production)
let transactions = [
    {
        id: '1',
        userId: '1',
        type: 'sent',
        recipientId: '2',
        recipientName: 'Jane Smith',
        recipientPhone: '+2202345678',
        amount: 150.00,
        fee: 5.00,
        total: 155.00,
        note: 'Lunch payment',
        status: 'success',
        createdAt: moment().subtract(1, 'day').toISOString()
    },
    {
        id: '2',
        userId: '1',
        type: 'received',
        senderId: '3',
        senderName: 'Mike Johnson',
        senderPhone: '+2203456789',
        amount: 300.00,
        fee: 0.00,
        total: 300.00,
        note: 'Payment for services',
        status: 'success',
        createdAt: moment().subtract(2, 'days').toISOString()
    },
    {
        id: '3',
        userId: '1',
        type: 'bills',
        service: 'Electricity',
        amount: 75.00,
        fee: 2.00,
        total: 77.00,
        note: 'Monthly bill',
        status: 'success',
        createdAt: moment().subtract(3, 'days').toISOString()
    }
];

// Mock users for recipient lookup
let users = [
    {
        id: '1',
        name: 'John Doe',
        email: 'john@example.com',
        phone: '+2201234567',
        balance: 1250.00
    },
    {
        id: '2',
        name: 'Jane Smith',
        email: 'jane@example.com',
        phone: '+2202345678',
        balance: 500.00
    },
    {
        id: '3',
        name: 'Mike Johnson',
        email: 'mike@example.com',
        phone: '+2203456789',
        balance: 800.00
    }
];

// Middleware to validate JWT token (import from auth.js in production)
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ success: false, message: 'Access token required' });
    }

    // For demo purposes, we'll assume the token is valid
    // In production, verify the JWT token
    req.user = { userId: '1' };
    next();
};

// Get user's transaction history
router.get('/', authenticateToken, (req, res) => {
    try {
        const { page = 1, limit = 10, type, status } = req.query;
        const userId = req.user.userId;

        // Filter transactions by user
        let userTransactions = transactions.filter(t => t.userId === userId);

        // Apply filters
        if (type) {
            userTransactions = userTransactions.filter(t => t.type === type);
        }

        if (status) {
            userTransactions = userTransactions.filter(t => t.status === status);
        }

        // Sort by creation date (newest first)
        userTransactions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        // Pagination
        const startIndex = (page - 1) * limit;
        const endIndex = page * limit;
        const paginatedTransactions = userTransactions.slice(startIndex, endIndex);

        res.json({
            success: true,
            data: {
                transactions: paginatedTransactions,
                pagination: {
                    currentPage: parseInt(page),
                    totalPages: Math.ceil(userTransactions.length / limit),
                    totalTransactions: userTransactions.length,
                    hasNextPage: endIndex < userTransactions.length,
                    hasPrevPage: page > 1
                }
            }
        });

    } catch (error) {
        console.error('Get transactions error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Get transaction by ID
router.get('/:id', authenticateToken, (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.userId;

        const transaction = transactions.find(t => t.id === id && t.userId === userId);

        if (!transaction) {
            return res.status(404).json({
                success: false,
                message: 'Transaction not found'
            });
        }

        res.json({
            success: true,
            data: transaction
        });

    } catch (error) {
        console.error('Get transaction error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Send money
router.post('/send', [
    body('recipientPhone').matches(/^\+?[1-9]\d{1,14}$/).withMessage('Valid phone number required'),
    body('amount').isFloat({ min: 1 }).withMessage('Amount must be at least 1'),
    body('note').optional().isLength({ max: 100 }).withMessage('Note must be less than 100 characters')
], authenticateToken, (req, res) => {
    try {
        // Check validation errors
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errors.array()
            });
        }

        const { recipientPhone, amount, note } = req.body;
        const senderId = req.user.userId;

        // Find sender
        const sender = users.find(u => u.id === senderId);
        if (!sender) {
            return res.status(404).json({
                success: false,
                message: 'Sender not found'
            });
        }

        // Find recipient
        const recipient = users.find(u => u.phone === recipientPhone);
        if (!recipient) {
            return res.status(404).json({
                success: false,
                message: 'Recipient not found'
            });
        }

        // Check if sender is trying to send to themselves
        if (sender.id === recipient.id) {
            return res.status(400).json({
                success: false,
                message: 'Cannot send money to yourself'
            });
        }

        // Calculate fee (5 GMD for transfers)
        const fee = 5.00;
        const total = amount + fee;

        // Check if sender has sufficient balance
        if (sender.balance < total) {
            return res.status(400).json({
                success: false,
                message: 'Insufficient balance'
            });
        }

        // Create transaction
        const transaction = {
            id: uuidv4(),
            userId: senderId,
            type: 'sent',
            recipientId: recipient.id,
            recipientName: recipient.name,
            recipientPhone: recipient.phone,
            amount: parseFloat(amount),
            fee,
            total,
            note: note || '',
            status: 'success',
            createdAt: new Date().toISOString()
        };

        // Update sender balance
        sender.balance -= total;

        // Update recipient balance
        recipient.balance += parseFloat(amount);

        // Add transaction to history
        transactions.push(transaction);

        // Create received transaction for recipient
        const receivedTransaction = {
            id: uuidv4(),
            userId: recipient.id,
            type: 'received',
            senderId: sender.id,
            senderName: sender.name,
            senderPhone: sender.phone,
            amount: parseFloat(amount),
            fee: 0.00,
            total: parseFloat(amount),
            note: note || '',
            status: 'success',
            createdAt: new Date().toISOString()
        };

        transactions.push(receivedTransaction);

        res.status(201).json({
            success: true,
            message: 'Money sent successfully',
            data: {
                transaction,
                newBalance: sender.balance
            }
        });

    } catch (error) {
        console.error('Send money error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Get user balance
router.get('/balance', authenticateToken, (req, res) => {
    try {
        const userId = req.user.userId;
        const user = users.find(u => u.id === userId);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        res.json({
            success: true,
            data: {
                balance: user.balance,
                currency: 'GMD'
            }
        });

    } catch (error) {
        console.error('Get balance error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Get transaction statistics
router.get('/stats', authenticateToken, (req, res) => {
    try {
        const userId = req.user.userId;
        const userTransactions = transactions.filter(t => t.userId === userId);

        const stats = {
            totalTransactions: userTransactions.length,
            totalSent: userTransactions
                .filter(t => t.type === 'sent')
                .reduce((sum, t) => sum + t.amount, 0),
            totalReceived: userTransactions
                .filter(t => t.type === 'received')
                .reduce((sum, t) => sum + t.amount, 0),
            totalBills: userTransactions
                .filter(t => t.type === 'bills')
                .reduce((sum, t) => sum + t.amount, 0),
            totalFees: userTransactions.reduce((sum, t) => sum + t.fee, 0),
            thisMonth: userTransactions
                .filter(t => moment(t.createdAt).isSame(moment(), 'month'))
                .length,
            thisYear: userTransactions
                .filter(t => moment(t.createdAt).isSame(moment(), 'year'))
                .length
        };

        res.json({
            success: true,
            data: stats
        });

    } catch (error) {
        console.error('Get stats error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Search recipients
router.get('/recipients/search', authenticateToken, (req, res) => {
    try {
        const { q } = req.query;
        const userId = req.user.userId;

        if (!q || q.length < 2) {
            return res.json({
                success: true,
                data: []
            });
        }

        const searchTerm = q.toLowerCase();
        const results = users
            .filter(u => u.id !== userId) // Exclude current user
            .filter(u => 
                u.name.toLowerCase().includes(searchTerm) ||
                u.phone.includes(searchTerm) ||
                u.email.toLowerCase().includes(searchTerm)
            )
            .map(u => ({
                id: u.id,
                name: u.name,
                phone: u.phone,
                email: u.email
            }))
            .slice(0, 10); // Limit results

        res.json({
            success: true,
            data: results
        });

    } catch (error) {
        console.error('Search recipients error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

module.exports = router; 