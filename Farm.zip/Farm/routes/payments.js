const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const moment = require('moment');
const router = express.Router();

// In-memory storage (replace with database in production)
let payments = [];
let users = [
    {
        id: '1',
        name: 'John Doe',
        email: 'john@example.com',
        phone: '+2201234567',
        balance: 1250.00
    }
];

// Middleware to validate JWT token
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ success: false, message: 'Access token required' });
    }

    req.user = { userId: '1' };
    next();
};

// Add cash to wallet
router.post('/topup', [
    body('amount').isFloat({ min: 10 }).withMessage('Amount must be at least 10 GMD'),
    body('paymentMethod').isIn(['bank', 'mobile-money', 'card']).withMessage('Invalid payment method'),
    body('paymentDetails').isObject().withMessage('Payment details required')
], authenticateToken, (req, res) => {
    try {
        // Check validation errors
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errors.array()
            });
        }

        const { amount, paymentMethod, paymentDetails } = req.body;
        const userId = req.user.userId;

        // Find user
        const user = users.find(u => u.id === userId);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        // Create payment record
        const payment = {
            id: uuidv4(),
            userId,
            type: 'topup',
            amount: parseFloat(amount),
            paymentMethod,
            paymentDetails,
            status: 'pending',
            createdAt: new Date().toISOString()
        };

        // Simulate payment processing
        setTimeout(() => {
            // Update payment status
            payment.status = 'success';
            payment.processedAt = new Date().toISOString();

            // Update user balance
            user.balance += parseFloat(amount);

            // Create transaction record
            const transaction = {
                id: uuidv4(),
                userId,
                type: 'received',
                senderId: 'system',
                senderName: 'Top-up',
                senderPhone: 'System',
                amount: parseFloat(amount),
                fee: 0.00,
                total: parseFloat(amount),
                note: `Added via ${paymentMethod}`,
                status: 'success',
                createdAt: new Date().toISOString()
            };

            payments.push(payment);
            // Note: In production, you'd also add this to the transactions array

            console.log(`Top-up successful: ${amount} GMD added to ${user.name}'s wallet`);
        }, 2000);

        res.status(201).json({
            success: true,
            message: 'Top-up initiated successfully',
            data: {
                paymentId: payment.id,
                amount: payment.amount,
                status: payment.status
            }
        });

    } catch (error) {
        console.error('Top-up error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Get payment methods
router.get('/methods', authenticateToken, (req, res) => {
    try {
        const paymentMethods = [
            {
                id: 'bank',
                name: 'Bank Transfer',
                description: 'Transfer from your bank account',
                icon: 'fas fa-university',
                processingTime: '1-2 business days',
                fee: 0.00,
                minAmount: 50,
                maxAmount: 10000
            },
            {
                id: 'mobile-money',
                name: 'Mobile Money',
                description: 'Pay with your mobile money account',
                icon: 'fas fa-mobile-alt',
                processingTime: 'Instant',
                fee: 2.00,
                minAmount: 10,
                maxAmount: 5000
            },
            {
                id: 'card',
                name: 'Credit/Debit Card',
                description: 'Pay with your card securely',
                icon: 'fas fa-credit-card',
                processingTime: 'Instant',
                fee: 3.00,
                minAmount: 10,
                maxAmount: 10000
            }
        ];

        res.json({
            success: true,
            data: paymentMethods
        });

    } catch (error) {
        console.error('Get payment methods error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Get payment history
router.get('/history', authenticateToken, (req, res) => {
    try {
        const userId = req.user.userId;
        const userPayments = payments.filter(p => p.userId === userId);

        // Sort by creation date (newest first)
        userPayments.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        res.json({
            success: true,
            data: userPayments
        });

    } catch (error) {
        console.error('Get payment history error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Get payment by ID
router.get('/:id', authenticateToken, (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.userId;

        const payment = payments.find(p => p.id === id && p.userId === userId);

        if (!payment) {
            return res.status(404).json({
                success: false,
                message: 'Payment not found'
            });
        }

        res.json({
            success: true,
            data: payment
        });

    } catch (error) {
        console.error('Get payment error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Cancel payment
router.post('/:id/cancel', authenticateToken, (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.userId;

        const payment = payments.find(p => p.id === id && p.userId === userId);

        if (!payment) {
            return res.status(404).json({
                success: false,
                message: 'Payment not found'
            });
        }

        if (payment.status !== 'pending') {
            return res.status(400).json({
                success: false,
                message: 'Payment cannot be cancelled'
            });
        }

        payment.status = 'cancelled';
        payment.cancelledAt = new Date().toISOString();

        res.json({
            success: true,
            message: 'Payment cancelled successfully',
            data: payment
        });

    } catch (error) {
        console.error('Cancel payment error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Get payment statistics
router.get('/stats', authenticateToken, (req, res) => {
    try {
        const userId = req.user.userId;
        const userPayments = payments.filter(p => p.userId === userId);

        const stats = {
            totalPayments: userPayments.length,
            totalAmount: userPayments.reduce((sum, p) => sum + p.amount, 0),
            successfulPayments: userPayments.filter(p => p.status === 'success').length,
            pendingPayments: userPayments.filter(p => p.status === 'pending').length,
            cancelledPayments: userPayments.filter(p => p.status === 'cancelled').length,
            thisMonth: userPayments.filter(p => moment(p.createdAt).isSame(moment(), 'month')).length,
            thisYear: userPayments.filter(p => moment(p.createdAt).isSame(moment(), 'year')).length
        };

        res.json({
            success: true,
            data: stats
        });

    } catch (error) {
        console.error('Get payment stats error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

module.exports = router; 