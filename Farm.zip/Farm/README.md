# 🚀 FarmPay - Mobile Money Application

A complete full-stack mobile money web application with modern UI/UX and robust backend API.

## 📋 Features

### Frontend Features
- ✅ **Landing/Onboarding Pages** - Welcome, Login, Signup, Forgot Password
- ✅ **Dashboard** - Balance overview, quick actions, recent transactions
- ✅ **Send Money** - Recipient selection, amount input, confirmation
- ✅ **Add Cash** - Multiple payment methods, quick amounts
- ✅ **Pay Bills** - Bill categories, payment processing
- ✅ **Transaction History** - Filtered view, status indicators
- ✅ **Profile Management** - User settings, account management
- ✅ **Responsive Design** - Mobile-first approach
- ✅ **Modern UI/UX** - Beautiful animations and transitions

### Backend Features
- ✅ **Authentication** - JWT-based auth, password hashing
- ✅ **User Management** - Registration, login, profile updates
- ✅ **Transaction Processing** - Send money, balance management
- ✅ **Payment Processing** - Top-up functionality, payment methods
- ✅ **Bill Payments** - Bill categories, payment processing
- ✅ **API Security** - Input validation, error handling
- ✅ **RESTful API** - Clean, documented endpoints

## 🛠️ Tech Stack

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Modern styling with gradients and animations
- **JavaScript (ES6+)** - Async/await, fetch API
- **Font Awesome** - Beautiful icons
- **Responsive Design** - Mobile-first approach

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **JWT** - Authentication tokens
- **bcryptjs** - Password hashing
- **express-validator** - Input validation
- **CORS** - Cross-origin resource sharing
- **Helmet** - Security headers

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd Farm
```

2. **Install backend dependencies**
```bash
npm install
```

3. **Set up environment variables**
```bash
# Copy the config file
cp config.env .env
# Edit .env with your configuration
```

4. **Start the backend server**
```bash
npm start
# or for development with auto-restart
npm run dev
```

5. **Access the application**
- Frontend: http://localhost:3000
- API: http://localhost:3000/api
- Health Check: http://localhost:3000/api/health

## 📱 API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/auth/profile` - Get user profile
- `POST /api/auth/forgot-password` - Forgot password
- `POST /api/auth/reset-password` - Reset password
- `POST /api/auth/logout` - Logout

### Transactions
- `GET /api/transactions` - Get transaction history
- `GET /api/transactions/:id` - Get specific transaction
- `POST /api/transactions/send` - Send money
- `GET /api/transactions/balance` - Get user balance
- `GET /api/transactions/stats` - Get transaction statistics
- `GET /api/transactions/recipients/search` - Search recipients

### Payments
- `POST /api/payments/topup` - Add cash to wallet
- `GET /api/payments/methods` - Get payment methods
- `GET /api/payments/history` - Get payment history
- `GET /api/payments/:id` - Get specific payment
- `POST /api/payments/:id/cancel` - Cancel payment
- `GET /api/payments/stats` - Get payment statistics

### Bills
- `GET /api/bills/categories` - Get bill categories
- `GET /api/bills` - Get user bills
- `GET /api/bills/:id` - Get specific bill
- `POST /api/bills/:id/pay` - Pay bill
- `GET /api/bills/payments` - Get bill payment history
- `GET /api/bills/stats` - Get bill statistics

### Users
- `GET /api/users/profile` - Get user profile
- `PUT /api/users/profile` - Update user profile
- `PUT /api/users/password` - Change password
- `GET /api/users/settings` - Get user settings
- `PUT /api/users/settings` - Update user settings
- `DELETE /api/users/account` - Delete account
- `GET /api/users/stats` - Get user statistics

## 🔧 Configuration

### Environment Variables
```env
# Server Configuration
PORT=3000
NODE_ENV=development

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key

# Frontend URL
FRONTEND_URL=http://localhost:3000
```

### Database (Future Implementation)
The current version uses in-memory storage. For production, you can integrate with:
- PostgreSQL
- MongoDB
- MySQL

## 🧪 Testing

### Manual Testing
1. **Registration**: Create a new account
2. **Login**: Use the demo account (john@example.com / password)
3. **Send Money**: Try sending money to another user
4. **Add Cash**: Test the top-up functionality
5. **Pay Bills**: Test bill payment features
6. **Transaction History**: View and filter transactions

### API Testing
Use tools like Postman or curl to test the API endpoints:

```bash
# Test health endpoint
curl http://localhost:3000/api/health

# Test login
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"john@example.com","password":"password"}'
```

## 🔒 Security Features

- **JWT Authentication** - Secure token-based auth
- **Password Hashing** - bcrypt with salt rounds
- **Input Validation** - Comprehensive validation
- **CORS Protection** - Cross-origin security
- **Helmet Security** - Security headers
- **Error Handling** - Proper error responses

## 📱 Mobile Features

- **Touch Gestures** - Swipe to navigate
- **Responsive Design** - Works on all devices
- **Offline Support** - Basic offline functionality
- **Push Notifications** - Ready for implementation
- **Biometric Auth** - Ready for implementation

## 🚀 Deployment

### Development
```bash
npm run dev
```

### Production
```bash
npm start
```

### Docker (Future)
```bash
docker build -t farmpay .
docker run -p 3000:3000 farmpay
```

## 📊 Performance

- **Frontend**: Optimized CSS and JavaScript
- **Backend**: Efficient API responses
- **Caching**: Ready for Redis integration
- **CDN**: Ready for static asset optimization

## 🔮 Future Enhancements

- **Database Integration** - PostgreSQL/MongoDB
- **Real-time Features** - WebSocket integration
- **Push Notifications** - Firebase/SMS integration
- **Payment Gateways** - Stripe/PayPal integration
- **Analytics** - User behavior tracking
- **Admin Panel** - User management interface
- **Multi-language** - Internationalization
- **Dark Mode** - Theme switching
- **Biometric Auth** - Fingerprint/Face ID
- **QR Code Payments** - Scan and pay

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Check the API documentation
- Review the code comments

---

**FarmPay** - Your trusted mobile money partner! 💰📱 